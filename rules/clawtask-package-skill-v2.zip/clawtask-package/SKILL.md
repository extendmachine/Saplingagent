---
name: clawtask-package
description: 将其他项目整理并打包成可上传到 ClawTask 群聊导入的 conversation v2.0 ZIP，检查启动入口、依赖、健康检查和归档安全。适用于准备 ClawTask 交付包或升级旧打包方案；不负责发布 ClawTask 平台本身。
---

# ClawTask 项目打包

目标是交付可导入、可恢复启动的项目 ZIP 和准确的运行说明。默认使用群聊项目包；只有用户明确选择外部 Compose/staging 纳管时，才读 [兼容接入说明](references/legacy-compose.md)。Skill 目录本身是给开发 AI 使用的工具，不是 ClawTask 运行期 Skill 导入包。

## 执行

1. 阅读目标项目自己的规则、依赖锁文件和启动代码，确认业务入口、运行时、构建步骤、配置变量与必要数据。保留项目原有架构和用户文件；不要把 ClawTask 自身的四服务、supervisor 或宿主路径套到其他项目。
2. 读 [包格式与运行契约](references/package-format.md)。把项目准备成可在 Linux 容器 `/app` 下运行的源码目录。前端需要的构建产物应明确纳入；macOS 的虚拟环境、原生二进制和 node_modules 不能当作 Linux 运行依赖搬运。多服务项目应说明同容器进程管理或外部依赖，提供一个供 Caddy 转发的 HTTP 入口，不默默改成多个 Docker 容器。
3. 准备兼容 POSIX `sh` 的 `start.sh`：从脚本所在目录定位文件，读取 `APP_PORT`（兼容 `PORT`），监听 `0.0.0.0`，前台 `exec` 启动。平台用 `sh /app/start.sh` 执行，因此 shebang 不能启用 Bash 专有语法。提供真实健康端点，不用固定成功响应掩盖依赖故障。
4. 分开说明首次依赖准备和日常启动。平台用户启动会执行入口并等待就绪，公开访问不会安装、构建或启动。不要把耗时联网安装塞进每次启动；依赖未满足时入口应清晰失败，交付说明列出用户启动容器后由 AI 在容器内完成的准备和重试步骤。纯源码包不能保证任意技术栈免准备运行。
5. 写 `clawtask-package.json`，明确 `title`、`goal`、`startup`、`include` 文件/目录白名单，按需 `exclude` glob。参考 [完整可运行样例](assets/demo/clawtask-package.json)。白名单只收运行源码、锁文件、构建产物、无密钥配置样例和必要项目说明；不要直接用整个仓库 `.`。脚本不读取 `.gitignore`，由明确清单决定交付范围。
6. 使用 Skill 随附脚本（仅 Python 3.10+ 标准库，不依赖 ClawTask 仓库或服务）：

   ```sh
   python3 /path/to/clawtask-package/scripts/package_project.py build \
     --source /path/to/project --config /path/to/project/clawtask-package.json \
     --output /path/to/output/project-clawtask-v2.zip
   python3 /path/to/clawtask-package/scripts/package_project.py validate \
     /path/to/output/project-clawtask-v2.zip
   ```

   输出文件必须尚不存在；重新生成用新文件名或在确认归属后移除旧产物。工具不会安装依赖、执行项目代码或上传。
7. 复核输出报告中的包含/排除文件列表，检查源码硬编码凭据和配置样例。过滤与私钥特征检查不能证明任意代码无密钥；疑似凭据只报告文件位置，不回显值。验证实际入口、端口、健康及必要业务功能；只有做过的验证才能标为通过。没有 Docker/目标环境时明确区分本地验证与真实容器验收。
8. 交付 ZIP 绝对路径、SHA-256、运行时/安装命令、入口/端口/健康路径、配置变量名、已验证项与剩余步骤。用户在群聊页面导入 ZIP，等待任务 `succeeded`；文件落入停止容器 `/app`。用户启动容器，确认应用就绪后在项目管理点击“公开访问”，使用应用端口。公网端口与 loopback 端口由平台管理，不能在包内指定宿主端口或 Caddy 配置。

## 旧包升级

- v1.0/v1.1 包虽然可被新平台适配，也必须检查源码和入口。仅改版本号不能修复旧宿主 workspace 路径、Compose-only 启动、缺少依赖或 Bash 语法。
- 旧 `meta.json/deploy.json/docker-compose.yml` 三件套不是群聊导入契约。新包必须真实组织 `conversation/workspace/` 与根清单，且不把旧 deploy.json 作为沙盒启动配置。
- 不把已有真实角色、聊天、知识或凭据默认带入新项目。需要迁移这些内容时优先使用目标站支持的原生导出，格式详见引用文档；本打包器只生成源码群聊包，不伪造身份或迁移历史。
- 不要求其他项目复制 clawtask 的 AGENTS/rules；目标项目的规则作为其自身内容按需保留。
