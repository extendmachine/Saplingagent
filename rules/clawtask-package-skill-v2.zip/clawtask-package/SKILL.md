---
name: clawtask-package
description: Organize and package other items into conversation v2.0 ZIP that can be uploaded to the ClawTask group chat import, and check the startup entrance, dependency, health check and archive security. It is suitable for preparing ClawTask delivery packages or upgrading old packaging schemes; it is not responsible for releasing the ClawTask platform itself.
---

# ClawTask project packaging

The goal is to deliver importable, restoreable project ZIP and accurate running instructions. By default, the group chat project package is used; only when the user explicitly selects the external Compose/staging manager, read [references/legacy-compose.md). The Skill directory itself is a tool for developing AI, not a ClawTask runtime Skill import package.

## Carry out

1. Read the target project's own rules, dependency lock files and startup codes, and confirm the business entrance, runtime, build steps, configuration variables and necessary data. Keep the original architecture and user files of the project; do not apply ClawTask's own four services, supervisor or host paths to other projects.
2. Read [package format and running contract] (references/package-format.md). Prepare the project as a source code directory that can run under the Linux container `/app`. The construction products required by the front-end should be clearly included; the virtual environment, native binary and node_modules of macOS cannot be handled as Linux running dependency. Multi-service projects should explain the same container process management or external dependence, provide an HTTP entrance for Caddy forwarding, and do not silently change to multiple Docker containers.
3. Prepare `start.sh` compatible with POSIX `sh`: locate the file from the directory where the script is located, read `APP_PORT` (compatible with `PORT`), listen to `0.0.0.0`, and start the front `exec`. The platform uses `sh /app/start.sh` to execute, so shebang cannot enable Bash proprietary syntax. Provide real health endpoints, and there is no need to fix the successful response to cover up dependent failures.
4. Separately explain the first dependence preparation and daily start-up. Platform users will execute the entry and wait for it to be ready, and public access will not be installed, built or started. Do not stuff the time-consuming network installation into each startup; when the dependency is not met, the entrance should clearly fail. The delivery instructions list the preparation and retry steps completed by AI in the container after the user starts the container. Pure source code packages cannot guarantee that any technology stack is free from ready-to-run.
5. Write `clawtask-package.json`, clarify `title`, `goal`, `startup`, `include` file/directory whitelist, `exclude` glob as needed. Refer to [complete executable sample] (assets/demo/clawtask-package.json). The white list only accepts running source code, lock files, construction products, keyless configuration samples and necessary project descriptions; do not use the entire warehouse directly. `. The script does not read `.gitignore`, and the delivery scope is determined by a clear list.
6. Use Skill accompanying scripts (Python 3.10+ standard library only, not dependent on ClawTask warehouse or service):

   ```sh
   python3 /path/to/clawtask-package/scripts/package_project.py build \
     --source /path/to/project --config /path/to/project/clawtask-package.json \
     --output /path/to/output/project-clawtask-v2.zip
   python3 /path/to/clawtask-package/scripts/package_project.py validate \
     /path/to/output/project-clawtask-v2.zip
   ```

   The output file must not exist yet; regenerate with a new file name or remove the old product after confirming the ownership. The tool will not install dependencies, execute project codes or upload.
7. Review the list of included/excluded files in the output report, and check the source code hard-coding credentials and configuration samples. Filtering and private key feature check cannot prove that any code has no key; suspected credentials only report the file location and do not return the value. Verify the actual entrance, port, health and necessary business functions; only the verification that has been done can be marked as passed. Clearly distinguish between local verification and real container acceptance when there is no Docker/target environment.
8. Delivery ZIP absolute path, SHA-256, runtime/installation command, entrance/port/health path, configuration variable name, verified items and remaining steps. The user imports ZIP on the group chat page and waits for the task `succeeded`; the file falls into the stop container `/app`. After the user starts the container and confirms that the application is ready, click "Open Access" in project management to use the application port. Public network ports and loopback ports are managed by the platform, and the host port or Caddy configuration cannot be specified in the package.

## Upgrade the old package

- Although the v1.0/v1.1 package can be adapted by the new platform, it must also check the source code and entrance. Only changing the version number cannot fix the old host workspace path, Compose-only startup, missing dependencies or Bash syntax.
- The old `meta.json/deploy.json/docker-compose.yml` three-piece set is not a group chat import contract. The new package must really organize `conversation/workspace/` with the root list, and do not configure the old deploy.json as a sandbox startup.
- Do not bring existing real roles, chats, knowledge or credentials into new projects by default. When you need to migrate these contents, give priority to the native export supported by the target station. For details of the format, please refer to the reference document; this packager only generates source code group chat packages and does not forge identity or migration history.
- Do not require other projects to copy the AGENTS/rules of clawtask; the rules of the target project are kept as their own content on demand.
