# Conversation v2.0 contract

Check date: 2026-09-09. According to the current working tree of ClawTask `shared/transfer_package.py`, `services/web/conversation_transfer.py`, `services/comm/package_transfer.py`, `services/deploy/package_transfer.py` and `sandbox_manager.py`. `scripts/package_contract.py` is a distribution snapshot of the shared package contract. When upgrading the back-end, it must be rechecked and returned with the real import decoder; this Skill does not need to access the above warehouse path to run.

## Necessary structure

```text
project-clawtask-v2.zip
├── manifest.json
└── conversation/
    ├── meta.json
    └── workspace/
        ├── start.sh
        ├── CLAWTASK_README.md
        └── ...Project source code and necessary construction files
```

```json
{
  "version": "2.0",
  "type": "conversation",
  "Title": "My project",
  "startup": {
    "workdir": "/app",
    "entrypoint": "/app/start.sh",
    "container_port": 8000,
    "healthcheck_path": "/api/health"
  },
  "includes": {"characters": false, "messages": false, "knowledge": false}
}
```

`conversation/meta.json` uses `{"title":"my project","goal":"project description"}`. No need for old station conv_id, human owner or member permissions. The source code is completely preserved relative to the path, and `workspace/foo` is mapped to `/app/foo`; the project directory can no longer be set outside the ZIP. Empty group chats without applications can omit startup, but this packager targets executable projects and requires explicit entrances.

Startup only allows four keys: workdir, entrypoint, container_port and healthcheck_path. The first two paths must be located in `/app`, and there must be no `.. `, backslash and other unsafe paths; the port is strictly JSON integer 1–65535 (recommended 8000), not 7000–9999 of the public network. The health path can be null or the URL path of this application beginning with a single `/`. Entrypoint must actually be in the archive; workdir must correspond to the source code root or existing subdirectory. The platform starts to inject `APP_PORT/PORT`, and public access does not inject the environment.

## Import, start and release are three steps.

1. Group chat import returns 202 and job_id through Web `POST /api/web/transfer/import` multipart `file`. Receiving success does not mean import completion; `succeeded` of `GET /api/web/transfer/jobs/{job_id}` indicates completion. Failed check error/cleanup_pending, retry the original task, avoid repeatedly uploading to create a group chat.
2. Import to create a stop container and write to `/app`, do not execute the file. When the user starts, execute `cd <workdir> && exec sh <entrypoint>`, inject the port, and wait for listening and health (HTTP 200–399). The first preparation takes too long to time, which may lead to a readiness timeout; complete the dependency in the activated container first, and then start the application and verify it. Retry the build without the public button.
3. "Public Access" only checks the running application and registers independent loopback forwarding and sharing Caddy; the original container, application process and file remain unchanged. Cancel the public and only cancel the entrance. The success of routing registration does not mean that the public network can be reached, and finally the URL returned by the platform needs to be verified; the internal CA certificate may need to be trusted by the user and cannot be claimed that there is no natural certificate prompt.

Do not control the host Docker, Caddy, systemd, 80/443/2019 with the package; do not write the server IP or fix the public network port. Don't think that `deploy.json.env` or the self-made image/build/env field in the list will configure the sandbox. When the key is required, only the variable name and security configuration steps are configured by the target environment; do not promise that the deployment variable UI of the old Compose will inject sandbox.

## Document security and boundaries

- ZIP ≤500 MiB, total expansion ≤1 GiB, entry ≤20000, single file ≤100 MiB; encryption, duplicate path, absolute path, crossing, symbolic link or special files are not allowed.
- Exclude `.git`, `.venv`, `node_modules`, cache, log, real `.env*`, `local-secrets`, selfdata, private key, operating system miscellaneous. Keep `.env.example/.env.sample` without real value. The old deploy.json is not exported with the source code, and the packager excludes it; the necessary configuration should be changed to the project's own keyless configuration entrance.
- The packager also excludes `.secrets/secrets`, `.git-credentials`, `.npmrc/.pypirc`, nested ZIP/mirror archiving to prevent bypassing file-by-file inspection; when the business really needs to archive assets, review and unpack them into ordinary files first, or deliver them separately.
- `.gitignore` is not equivalent to a delivery list; for example, the front-end dist may be a document that must be delivered. Whether the existing business database/material is delivered is decided according to the user's needs. It is not deleted all of them, and the running data is not carried by default.
- ZIP is a source code distribution, which does not contain data outside the system image, Linux dependency installed, and `/app`. Confirm that the target instance supports v2 before importing; local package verification does not represent any old instance compatibility.

Optional migration content: this group character `conversation/characters/<id>/card.json`, history `conversation/messages/*.jsonl`, knowledge `conversation/knowledge/**`. They have additional identity and reference checks, which are not generated by this source code packager. The Skill code in the group chat package will not be installed automatically; the independent role package `character_package v1.1` cannot be mixed with this format.
