# conversation v2.0 契约

核对日期：2026-09-09。依据 ClawTask 当前工作树 `shared/transfer_package.py`、`services/web/conversation_transfer.py`、`services/comm/package_transfer.py`、`services/deploy/package_transfer.py` 和 `sandbox_manager.py`。`scripts/package_contract.py` 是共享包契约的分发快照，升级后端时须重新核对并用真实导入解码器回归；此 Skill 不需要访问上述仓库路径才能运行。

## 必要结构

```text
project-clawtask-v2.zip
├── manifest.json
└── conversation/
    ├── meta.json
    └── workspace/
        ├── start.sh
        ├── CLAWTASK_README.md
        └── …项目源码与必要构建文件
```

```json
{
  "version": "2.0",
  "type": "conversation",
  "title": "我的项目",
  "startup": {
    "workdir": "/app",
    "entrypoint": "/app/start.sh",
    "container_port": 8000,
    "healthcheck_path": "/api/health"
  },
  "includes": {"characters": false, "messages": false, "knowledge": false}
}
```

`conversation/meta.json` 使用 `{"title":"我的项目","goal":"项目说明"}`。不需要旧站 conv_id、人类 owner 或成员权限。源码相对路径完整保留，`workspace/foo` 映射 `/app/foo`；ZIP 外面不能再套项目目录。无应用的空群聊可省略 startup，但本打包器以可运行项目为目标，要求显式入口。

startup 只允许 workdir、entrypoint、container_port、healthcheck_path 四键。前两个路径必须位于 `/app`，不能有 `..`、反斜线等不安全路径；端口是严格 JSON 整数 1–65535（推荐 8000），不是公网的 7000–9999。健康路径可为 null，或以单个 `/` 开头的本应用 URL 路径。entrypoint 必须实际在归档里；workdir 必须对应源码根或存在的子目录。平台启动注入 `APP_PORT/PORT`，公开访问不注入环境。

## 导入、启动、公开是三个步骤

1. 群聊导入通过 Web `POST /api/web/transfer/import` multipart `file` 返回 202 和 job_id。接收成功不等于导入完成；`GET /api/web/transfer/jobs/{job_id}` 的 `succeeded` 才表示完成。失败检查 error/cleanup_pending，原任务 retry，避免不断重复上传创建群聊。
2. 导入创建停止容器并写入 `/app`，不执行文件。用户启动时执行 `cd <workdir> && exec sh <entrypoint>`，注入端口，等待监听及健康（HTTP 200–399）。首次准备耗时过长可能导致就绪超时；先在已启动的容器内完成依赖，再启动应用并验证，不用公开按钮重试构建。
3. “公开访问”只检查已运行应用并注册独立 loopback 转发与共享 Caddy；原容器、应用进程、文件不变。取消公开只撤销入口。路由登记成功不等于公网可达，最终还要打开平台返回的 URL 验证；internal CA 证书可能需要用户信任，不能宣称天然无证书提示。

不随包控制宿主 Docker、Caddy、systemd、80/443/2019；不写服务器 IP 或固定公网端口。不要认为 `deploy.json.env` 或清单中自造的 image/build/env 字段会配置 sandbox。需要密钥时只列变量名和安全配置步骤，由目标环境配置；不要承诺旧 Compose 的部署变量 UI 会注入 sandbox。

## 文件安全与界限

- ZIP ≤500 MiB，展开总量 ≤1 GiB，条目 ≤20000，单文件 ≤100 MiB；不允许加密、重复路径、绝对路径、穿越、符号链接或特殊文件。
- 排除 `.git`、`.venv`、`node_modules`、缓存、日志、真实 `.env*`、`local-secrets`、selfdata、私钥、操作系统杂项。保留无真实值的 `.env.example/.env.sample`。旧 deploy.json 不随源码导出，打包器也排除它；必要配置应改用项目自己的无密钥配置入口。
- 打包器另外排除 `.secrets/secrets`、`.git-credentials`、`.npmrc/.pypirc`、嵌套 ZIP/镜像归档，防止绕过逐文件检查；业务确实需要归档资产时先审阅解开成普通文件，或单独交付。
- `.gitignore` 不等于交付清单；例如前端 dist 可能是必须交付的文件。现有业务数据库/素材是否交付按用户需求决定，不一概删除，也不默认携带运行数据。
- ZIP 是源码分发，不包含系统镜像、已安装 Linux 依赖、`/app` 外的数据。导入前确认目标实例支持 v2；本地包验证不代表任意旧实例兼容。

可选迁移内容：本群角色 `conversation/characters/<id>/card.json`，历史 `conversation/messages/*.jsonl`，知识 `conversation/knowledge/**`。它们有额外身份与引用校验，不由本源码打包器生成。群聊包内 Skill 代码不会自动安装；独立角色包 `character_package v1.1` 与本格式不能混合。
