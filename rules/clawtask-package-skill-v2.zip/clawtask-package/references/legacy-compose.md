# Old external Compose/staging compatibility path

Read only when the user clearly chooses independent external project management. The following is not the default scheme of group chat ZIP, nor the public access process of ordinary group chat project management. The old path check is based on ClawTask ops_ingest_scanner.py, ops_ingest_models.py and PROJECT_ONBOARDING.md; please return to SKILL.md for new group chat packages.

## 2. Deployment boundaries that AI must abide by

1. The external containment project in this section is started through `docker-compose.yml`; the group chat sandbox is a clear exception controlled by Deploy, using its existing container without creating a new Compose container.
2. The project can only expose one HTTP entrance; the business container port can only bind the host `127.0.0.1`.
3. The application in the container must listen to `0.0.0.0:<container port>`, otherwise the host port mapping cannot access it.
4. Do not occupy 22, 80, 443, 2019; public network HTTPS, certificates and routes are managed by shared Caddy.
5. Do not run `docker compose up`, `docker run`, `systemctl`, `certbot` by yourself, and do not directly modify the shared Caddy.
6. The real key should not be used in the source code and deployment description; the key is set by deploying variables through the platform after the project is taken.
7. Retain the database and persistence scheme according to the needs of the target project; the data migration is explained separately, and the running data and credentials are not packaged by default.

## 3. Root directory of valid projects

The following 3 files must be located directly in the root directory of the project and cannot be hidden in the second layer directory:

```text
my-tool/
├── meta.json
├── deploy.json
├── docker-compose.yml
├── Dockerfile # According to the needs of the project
├── start.sh # According to the needs of the project
└── <Business Code>
```

Example of error: Staging is already called `my-tool`, and there is an additional layer of `my-tool/` after decompression.

```text
/srv/clawtask-staging/my-tool/
└── my-tool/
    ├── meta.json # Wrong: scanner can't be found on the previous layer
    ├── deploy.json
    └── docker-compose.yml
```

## 4. Three deployment profiles

### 4.1 `meta.json`

```json
{
  "name": "my-tool",
  "Description": "A simple, stateless online tool",
  "owner": "team-name",
  "tags": ["tool", "stateless"]
}
```

- `name` must match `^[a-z][a-z0-9_-]{0,31}$`.
- In staging mode, `name` must be exactly the same directory name as `/srv/clawtask-staging/<name>/`.
- `description` and `owner` must be non-empty strings.

### 4.2 `deploy.json`

```json
{
  "port": 8080,
  "domain": "",
  "env": {}
}
```

- `port` must be a JSON integer and cannot be written as a string; the current ingestion verification range is 7000–9999.
- This value is injected as `OC_CONTAINER_PORT`, which is the port that is applied to listen in the container.
- Leave `domain` blank means using the IP entrance assigned by the platform first; when the domain name is needed, it is processed in the platform deployment configuration.
- `env` only puts non-sensitive default values, and the real token/API key is not allowed to enter the delivery package.

### 4.3 `docker-compose.yml`

Large-scale projects give priority to building `linux/amd64` mirror images locally or in CI and push mirroring warehouses. At this time will
`deploy.json.build_mode` is set to `remote_image`, and all services in Composite must be used.
`image: warehouse address @sha256:<abstract>` and must not contain `build:`. ClawTask will be deployed in asynchronous tasks.
Streaming mirroring, checking platform and starting with `--no-build --pull never`, users do not need to upload mirror archiving.

```yaml
services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    environment:
      APP_PORT: "${OC_CONTAINER_PORT:-8080}"
    ports:
      - "127.0.0.1:${OC_HOST_PORT}:${OC_CONTAINER_PORT:-8080}"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-fsS", "http://127.0.0.1:${OC_CONTAINER_PORT:-8080}/health"]
      interval: 30s
      timeout: 5s
      retries: 3
```

Requirements:

- The YAML root node must be an object and contain `services`.
- At least one service exposes HTTP; internal services such as databases and Redis should not publish ports.
- The host binding must be explicitly written `127.0.0.1:`, not `0.0.0.0:` or the binding address cannot be omitted.
- `OC_HOST_PORT` is assigned by ClawTask and cannot be hardcoded in the delivery package.
- The application process reads `APP_PORT` and listens to `0.0.0.0` in the container.

## Five. Two correct access processes

### Path A: There is already an independent Compose management project (not an ordinary group chat sandbox)

1. Confirm that the target is that there is already an independent Compose management project; the "public access" of ordinary group chat will not read the three-piece set of this section or build a mirror image. Open the workspace of the compatible project.
2. Use "Upload Folder" to select all the contents in the root directory of the project.
3. After uploading, confirm that the homepage of the work area directly displays `meta.json`, `deploy.json`, `docker-compose.yml`.
4. Do not expect the platform to automatically decompress after uploading the ZIP; the current work area upload will save the ZIP as an ordinary file.
5. Set the real deployment variable on the project management page, and then use the platform "Deploy" button.

### Path B: External Project Staging Ingestion

1. Complete the pre-inspection of Section 6 locally.
2. Send the project content to the server `/srv/clawtask-staging/<name>/`.
3. Check the first layer of the directory to see three essential files.
4. By default, scanner checks about once every 30 seconds; after the verification is successful, the project will be created and copied to the work area.
5. When the verification fails, the source directory will be retained. After repairing the original directory, wait for the next scan.

If it must be transmitted by ZIP, ZIP is only used for transmission, and the server side must be decompressed to the root of the staging project:

```bash
# Execute in the root directory of the project to ensure that the first layer of ZIP is meta.json and other files.
cd /path/to/my-tool
zip -r ../my-tool-deploy.zip . \
  -x '.git/*' '.venv/*' 'node_modules/*' 'logs/*' '*.log' '.env' 'selfdata.json'

# Server-side indication; the directory name must be the same as meta.json.name
mkdir -p /srv/clawtask-staging/my-tool
unzip my-tool-deploy.zip -d /srv/clawtask-staging/my-tool
```

Do not execute `zip -r my-tool-deploy.zip my-tool/`, otherwise the archive will usually have an additional layer of `my-tool/`.

## 6. AI pre-delivery pre-inspection

Execute in the root directory of the project:

```bash
test -f meta.json
test -f deploy.json
test -f docker-compose.yml
python -m json.tool meta.json >/dev/null
python -m json.tool deploy.json >/dev/null
OC_HOST_PORT=7999 OC_CONTAINER_PORT=8080 docker compose -f docker-compose.yml config >/dev/null
```

Then manual or AI check:

- [ ] `meta.json.name` is consistent with the staging directory name.
- [ ] `deploy.json.port` is an integer of 7000–9999.
- [ ] compose has `services`, and all host ports only bind `127.0.0.1`.
- [ ] The application provides `/health` and listens to `0.0.0.0` in the container.
- [ ] There is no `.env`, `selfdata.json`, private key, password, real API key, log and user content.
- [ ] The first layer of ZIP directly contains three required files; do not replace the `unzip -l` check with the visual hierarchy of the file manager.
- [ ] The business deployment ZIP was not handed over to the "Group Chat Import".

## Seven. Wrong comparison

| Phenomenon or log reason | Reason | Processing |
|---|---|---|
| `A valid manifest.json` is missing in the ZIP package | Go to the group chat migration package import entrance | Change to work area folder upload or staging; do not fake manifest |
| `missing_files` | The staging root directory lacks 3 required files, or ZIP multiple sets of first-layer directories | Move the file to `/srv/clawtask-staging/<name>/` first layer |
| `meta_json_parse` / `deploy_json_parse` | JSON syntax error | Use `python -m json.tool` to verify |
| `meta_schema` | name, description, owner or tags non-compliance | Correction according to Section 4.1 |
| `name_mismatch` | The directory name is different from `meta.json.name` | Unify the two |
| `deploy_schema` | port is not an integer or not 7000–9999 | Modify `deploy.json` |
| `compose_yaml` | Compose YAML cannot be parsed | Run `docker compose config` |
| `compose_no_services` | The root node is not an object or there is no `services` | Modify the Compose structure |
| Ingestion successful, deployment failed | Mirror build, health check, port or startup command error | View deploy service log and compose output, do not bypass the platform startup |

## 8. Return format when AI is completed

AI must not only reply "packaged". Must be given:

```text
Project name: <meta.json.name>
Access path: work area upload / staging
Project root: <local path or staging path>
Required documents: passed / failed
JSON Verification: Passed / Failed
Compose Check: Passed / Failed (Reason)
Sensitive Information Check: Passed / Failed
ZIP root hierarchy: pass / not applicable
Manual operation is still required: <Deploy variables, domain names or other matters>
```

