# 旧外部 Compose/staging 兼容路径

仅在用户明确选择独立外部项目纳管时阅读。以下不是群聊 ZIP 默认方案，也不是普通群聊项目管理的公开访问流程。旧路径校验依据 ClawTask ops_ingest_scanner.py、ops_ingest_models.py 与 PROJECT_ONBOARDING.md；群聊新包请返回 SKILL.md。

## 2. AI 必须遵守的部署边界

1. 本节外部纳管项目通过 `docker-compose.yml` 启动；群聊 sandbox 是受 Deploy 控制的明确例外，使用其已存在的容器，不新建 Compose 容器。
2. 项目只能暴露一个 HTTP 入口；业务容器端口只绑定宿主机 `127.0.0.1`。
3. 容器内应用必须监听 `0.0.0.0:<容器端口>`，否则宿主机端口映射无法访问它。
4. 不得占用 22、80、443、2019；公网 HTTPS、证书和路由由共享 Caddy 管理。
5. 不得自行运行 `docker compose up`、`docker run`、`systemctl`、`certbot`，也不得直接修改共享 Caddy。
6. 源码和部署描述中不得写真实密钥；密钥在项目摄取后通过平台部署变量设置。
7. 按目标项目需求保留数据库和持久化方案；数据迁移单独说明，不默认把运行数据和凭据打包。

## 3. 有效项目的根目录

下面 3 个文件必须直接位于项目根目录，不能藏在第二层目录中：

```text
my-tool/
├── meta.json
├── deploy.json
├── docker-compose.yml
├── Dockerfile                 # 按项目需要
├── start.sh                  # 按项目需要
└── <业务代码>
```

错误示例：staging 已经叫 `my-tool`，解压后又多出一层 `my-tool/`。

```text
/srv/clawtask-staging/my-tool/
└── my-tool/
    ├── meta.json             # 错：scanner 在上一层找不到
    ├── deploy.json
    └── docker-compose.yml
```

## 4. 三个部署描述文件

### 4.1 `meta.json`

```json
{
  "name": "my-tool",
  "description": "一个简单、无状态的在线工具",
  "owner": "team-name",
  "tags": ["tool", "stateless"]
}
```

- `name` 必须匹配 `^[a-z][a-z0-9_-]{0,31}$`。
- staging 模式下，`name` 必须与 `/srv/clawtask-staging/<name>/` 的目录名完全相同。
- `description`、`owner` 必须是非空字符串。

### 4.2 `deploy.json`

```json
{
  "port": 8080,
  "domain": "",
  "env": {}
}
```

- `port` 必须是 JSON 整数，不能写成字符串；当前摄取校验范围是 7000–9999。
- 该值作为 `OC_CONTAINER_PORT` 注入，是应用在容器内监听的端口。
- `domain` 留空表示先使用平台分配的 IP 入口；需要域名时在平台部署配置中处理。
- `env` 只放非敏感默认值，真实 token/API key 不得进入交付包。

### 4.3 `docker-compose.yml`

大型项目优先在本地或 CI 构建 `linux/amd64` 镜像并推送镜像仓库。此时将
`deploy.json.build_mode` 设为 `remote_image`，Compose 中所有服务都必须使用
`image: 仓库地址@sha256:<摘要>` 且不得包含 `build:`。ClawTask 会在异步部署任务中
流式拉取镜像、校验平台并以 `--no-build --pull never` 启动，用户无需上传镜像归档。

```yaml
services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    environment:
      APP_PORT: "${OC_CONTAINER_PORT:-8080}"
    ports:
      - "127.0.0.1:${OC_HOST_PORT}:${OC_CONTAINER_PORT:-8080}"
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-fsS", "http://127.0.0.1:${OC_CONTAINER_PORT:-8080}/health"]
      interval: 30s
      timeout: 5s
      retries: 3
```

要求：

- YAML 根节点必须是对象，并包含 `services`。
- 至少一个 service 暴露 HTTP；数据库、Redis 等内部服务不要 publish 端口。
- 宿主机绑定必须显式写 `127.0.0.1:`，不能写 `0.0.0.0:` 或省略绑定地址。
- `OC_HOST_PORT` 由 ClawTask 分配，不能在交付包中硬编码。
- 应用进程读取 `APP_PORT`，并在容器内监听 `0.0.0.0`。

## 5. 两条正确接入流程

### 路径 A：已有独立 Compose 纳管项目（不是普通群聊 sandbox）

1. 确认目标是已有独立 Compose 纳管项目；普通群聊的“公开访问”不会读取本节三件套或构建镜像。打开该兼容项目的工作区。
2. 使用“上传文件夹”，选中项目根目录中的全部内容。
3. 上传后确认工作区首页直接显示 `meta.json`、`deploy.json`、`docker-compose.yml`。
4. 不要上传 ZIP 后期待平台自动解压；当前工作区上传会把 ZIP 当作普通文件保存。
5. 在项目管理页设置真实部署变量，然后使用平台“部署”按钮。

### 路径 B：外部项目 staging 摄取

1. 在本地完成第 6 节预检。
2. 把项目内容传到服务器 `/srv/clawtask-staging/<name>/`。
3. 检查该目录的第一层就能看到三个必备文件。
4. scanner 默认约每 30 秒检查一次；校验成功后会创建项目并复制到工作区。
5. 校验失败时源目录会保留，修复原目录后等待下一次扫描。

如果必须用 ZIP 传输，ZIP 只用于传输，服务器端必须解压到 staging 项目根：

```bash
# 在项目根目录内执行，确保 ZIP 第一层就是 meta.json 等文件
cd /path/to/my-tool
zip -r ../my-tool-deploy.zip . \
  -x '.git/*' '.venv/*' 'node_modules/*' 'logs/*' '*.log' '.env' 'selfdata.json'

# 服务器端示意；目录名必须与 meta.json.name 相同
mkdir -p /srv/clawtask-staging/my-tool
unzip my-tool-deploy.zip -d /srv/clawtask-staging/my-tool
```

不要执行 `zip -r my-tool-deploy.zip my-tool/`，否则归档通常会多一层 `my-tool/`。

## 6. AI 交付前预检

在项目根目录执行：

```bash
test -f meta.json
test -f deploy.json
test -f docker-compose.yml
python -m json.tool meta.json >/dev/null
python -m json.tool deploy.json >/dev/null
OC_HOST_PORT=7999 OC_CONTAINER_PORT=8080 docker compose -f docker-compose.yml config >/dev/null
```

然后人工或 AI 检查：

- [ ] `meta.json.name` 与 staging 目录名一致。
- [ ] `deploy.json.port` 为 7000–9999 的整数。
- [ ] compose 有 `services`，所有宿主机端口只绑定 `127.0.0.1`。
- [ ] 应用提供 `/health`，且容器内监听 `0.0.0.0`。
- [ ] 没有 `.env`、`selfdata.json`、私钥、密码、真实 API key、日志和用户内容。
- [ ] ZIP 第一层直接包含三个必备文件；不要以文件管理器的视觉层级代替 `unzip -l` 检查。
- [ ] 没有把业务部署 ZIP 交给“群聊导入”。

## 7. 错误对照

| 现象或日志 reason | 原因 | 处理 |
|---|---|---|
| `ZIP 包中缺少有效的 manifest.json` | 走了群聊迁移包导入入口 | 改走工作区文件夹上传或 staging；不要伪造 manifest |
| `missing_files` | staging 根目录缺 3 个必备文件，或 ZIP 多套一层目录 | 把文件移动到 `/srv/clawtask-staging/<name>/` 第一层 |
| `meta_json_parse` / `deploy_json_parse` | JSON 语法错误 | 使用 `python -m json.tool` 校验 |
| `meta_schema` | name、description、owner 或 tags 不合规 | 按第 4.1 节修正 |
| `name_mismatch` | 目录名与 `meta.json.name` 不同 | 统一二者 |
| `deploy_schema` | port 不是整数或不在 7000–9999 | 修正 `deploy.json` |
| `compose_yaml` | Compose YAML 无法解析 | 运行 `docker compose config` |
| `compose_no_services` | 根节点不是对象或没有 `services` | 修正 Compose 结构 |
| 摄取成功、部署失败 | 镜像构建、健康检查、端口或启动命令错误 | 查看 deploy 服务日志和 compose 输出，不绕过平台启动 |

## 8. AI 完成时的回报格式

AI 不得只回复“已经打包”。必须给出：

```text
项目名：<meta.json.name>
接入路径：工作区上传 / staging
项目根：<本地路径或 staging 路径>
必备文件：通过 / 未通过
JSON 校验：通过 / 未通过
Compose 校验：通过 / 未执行（原因）
敏感信息检查：通过 / 未通过
ZIP 根层级：通过 / 不适用
仍需人工操作：<部署变量、域名或其他事项>
```

