# ClawTask v2 executeable sample

Runtime: Linux + Python 3.10 or later, standard library only, no pip, Node or Docker construction required, no configuration key, no persistent data. The actual project should be replaced with its own runtime version, lock file installation and build command.

Import the project ZIP on the group chat page and wait for the task to succeed. The file enters the stop container `/app`. After clicking to start the container, the platform starts the application through `sh /app/start.sh`, and APP_PORT/PORT defaults to 8000. Home page `/`, health path `/api/health` should return HTTP 200, ok=true.

If the container has been started but the application is not ready, AI can check `python3 --version` and `/var/log/clawtask-project.log` in the container. After repairing the environment, use `cd /app && APP_PORT=8000 sh start.sh` to start and check the health to avoid starting duplicate processes. After the application is ready, the user fills in the container port 8000 in the project management "public access" and opens the URL returned by the platform. The public button is not responsible for installation or activation; canceling the public does not close the application.

The startup script of this sample uses relative positioning, and the unpacked temporary directory can also be started; it does not depend on the local developer path. Stop and restart the container to re-execute the entrance. Only the local test pass cannot replace the real import of the target station, container startup and public network access acceptance.
