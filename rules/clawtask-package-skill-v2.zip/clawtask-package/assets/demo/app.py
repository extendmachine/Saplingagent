"""No-dependency sample: one HTTP entry, no filesystem or credential access."""
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/health":
            body = json.dumps({"ok": True, "package_version": "2.0"}).encode()
            content_type = "application/json"
        elif self.path == "/":
            body = "<!doctype html><meta charset='utf-8'><title>ClawTask v2</title><h1>ClawTask 项目已启动</h1><p>源码导入与应用启动成功。</p>".encode()
            content_type = "text/html; charset=utf-8"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    port = int(os.environ.get("APP_PORT", os.environ.get("PORT", "8000")))
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
