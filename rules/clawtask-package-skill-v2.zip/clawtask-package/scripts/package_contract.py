"""Portable package contract. No service-private imports or filesystem extraction."""
from __future__ import annotations

import io
import json
import stat
import zipfile
from pathlib import PurePosixPath

MAX_UPLOAD = 500 * 1024 * 1024
MAX_EXPANDED = 1024 * 1024 * 1024
MAX_ENTRIES = 20000
MAX_FILE = 100 * 1024 * 1024


def safe_path(name: str) -> str:
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name:
        raise ValueError("The path in the package is invalid.")
    path = PurePosixPath(name)
    if path.is_absolute() or any(p in {"", ".", ".."} for p in name.rstrip("/").split("/")) or ":" in name:
        raise ValueError("The path in the package must be a secure relative path.")
    return str(path)


def open_package(content: bytes) -> zipfile.ZipFile:
    if len(content) > MAX_UPLOAD:
        raise ValueError("ZIP exceeds 500MB")
    archive = zipfile.ZipFile(io.BytesIO(content))
    try:
        entries = archive.infolist()
        if len(entries) > MAX_ENTRIES or sum(i.file_size for i in entries) > MAX_EXPANDED:
            raise ValueError("ZIP decompression size or the number of files exceeds the limit")
        names = set()
        files = set()
        for entry in entries:
            path = safe_path(entry.filename)
            mode = stat.S_IFMT(entry.external_attr >> 16)
            if mode not in (0, stat.S_IFREG, stat.S_IFDIR) or entry.flag_bits & 1:
                raise ValueError("ZIP does not allow links, special files or encrypted files.")
            if path in names or entry.file_size > MAX_FILE:
                raise ValueError("ZIP contains duplicate paths or a single file exceeds 100MB")
            names.add(path)
            if not entry.is_dir():
                files.add(path)
        for path in names:
            if any(str(p) in files for p in PurePosixPath(path).parents):
                raise ValueError("ZIP file conflicts with directory paths")
        return archive
    except Exception:
        archive.close()
        raise


def package_manifest(archive: zipfile.ZipFile) -> dict:
    value = json.loads(archive.read("manifest.json"))
    if not isinstance(value, dict) or not isinstance(value.get("version"), str) or value.get("version") not in {"1.0", "1.1", "2.0"}:
        raise ValueError("Unsupported package versions; support 1.0, 1.1, 2.0")
    has_conv = any(n.startswith("conversation/") for n in archive.namelist())
    kind = value.get("type") or ("conversation" if has_conv else "character")
    if not isinstance(kind, str) or kind not in {"conversation", "character_package", "character", "skill"}:
        raise ValueError("Unknown import package type")
    if has_conv != (kind == "conversation"):
        raise ValueError("Group chat packages cannot be mixed with independent role/skill packages.")
    if value["version"] == "2.0" and kind != "conversation":
        raise ValueError("V2.0 is only used for group chat packages")
    value["type"] = kind
    if kind == "conversation":
        value["startup"] = validate_startup(value.get("startup"))
    return value


def validate_startup(value: dict | None) -> dict:
    if value is None or value == {}:
        return {}
    if not isinstance(value, dict) or set(value) - {"workdir", "entrypoint", "container_port", "healthcheck_path"}:
        raise ValueError("Startup configuration contains unsupported fields")
    result = {"workdir": value.get("workdir", "/app"),
              "entrypoint": value.get("entrypoint", "/app/start.sh"),
              "container_port": value.get("container_port", 8000),
              "healthcheck_path": value.get("healthcheck_path")}
    for key in ("workdir", "entrypoint"):
        path = result[key]
        if not isinstance(path, str) or not (path == "/app" or path.startswith("/app/")):
            raise ValueError("The boot directory and entrance must be located in /app")
        safe_path(path[1:])
    if type(result["container_port"]) is not int or not 1 <= result["container_port"] <= 65535:
        raise ValueError("The container port must be 1–65535")
    health = result["healthcheck_path"]
    if health is not None and (not isinstance(health, str) or not health.startswith("/") or health.startswith("//") or any(c in health for c in "\r\n\\")):
        raise ValueError("Health check must be the relative URL path of this application.")
    return result


def portable_source(path: str) -> bool:
    parts = PurePosixPath(path).parts
    denied = {".git", ".venv", "venv", "node_modules", "__pycache__", ".cache", "logs", "local-secrets", ".ssh", ".aws"}
    if any(p in denied or p.startswith("._") for p in parts):
        return False
    name = parts[-1].lower()
    return not (name == ".env" or (name.startswith(".env.") and name not in {".env.example", ".env.sample"})
                or name.startswith("selfdata") or name.endswith((".pem", ".key", ".p12", ".pfx", ".log", ".pyc"))
                or name in {"id_rsa", "id_ed25519", ".ds_store", "deploy.json"})


def strip_credentials(value):
    """Model/provider credentials are never portable; text instructions remain content."""
    if isinstance(value, dict):
        return {k: strip_credentials(v) for k, v in value.items()
                if not any(word in k.lower() for word in ("password", "secret", "token", "api_key", "apikey", "private_key"))
                and k not in {"module", "module_config", "package_id", "package_role_id"}}
    if isinstance(value, list):
        return [strip_credentials(v) for v in value]
    return value
