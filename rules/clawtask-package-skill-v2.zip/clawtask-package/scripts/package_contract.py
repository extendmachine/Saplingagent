"""Portable package contract. No service-private imports or filesystem extraction."""
from __future__ import annotations

import io
import json
import stat
import zipfile
from pathlib import PurePosixPath

MAX_UPLOAD = 500 * 1024 * 1024
MAX_EXPANDED = 1024 * 1024 * 1024
MAX_ENTRIES = 20000
MAX_FILE = 100 * 1024 * 1024


def safe_path(name: str) -> str:
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name:
        raise ValueError("包内路径无效")
    path = PurePosixPath(name)
    if path.is_absolute() or any(p in {"", ".", ".."} for p in name.rstrip("/").split("/")) or ":" in name:
        raise ValueError("包内路径必须是安全相对路径")
    return str(path)


def open_package(content: bytes) -> zipfile.ZipFile:
    if len(content) > MAX_UPLOAD:
        raise ValueError("ZIP 超过 500MB")
    archive = zipfile.ZipFile(io.BytesIO(content))
    try:
        entries = archive.infolist()
        if len(entries) > MAX_ENTRIES or sum(i.file_size for i in entries) > MAX_EXPANDED:
            raise ValueError("ZIP 解压大小或文件数超限")
        names = set()
        files = set()
        for entry in entries:
            path = safe_path(entry.filename)
            mode = stat.S_IFMT(entry.external_attr >> 16)
            if mode not in (0, stat.S_IFREG, stat.S_IFDIR) or entry.flag_bits & 1:
                raise ValueError("ZIP 不允许链接、特殊文件或加密文件")
            if path in names or entry.file_size > MAX_FILE:
                raise ValueError("ZIP 含重复路径或单文件超过 100MB")
            names.add(path)
            if not entry.is_dir():
                files.add(path)
        for path in names:
            if any(str(p) in files for p in PurePosixPath(path).parents):
                raise ValueError("ZIP 文件与目录路径冲突")
        return archive
    except Exception:
        archive.close()
        raise


def package_manifest(archive: zipfile.ZipFile) -> dict:
    value = json.loads(archive.read("manifest.json"))
    if not isinstance(value, dict) or not isinstance(value.get("version"), str) or value.get("version") not in {"1.0", "1.1", "2.0"}:
        raise ValueError("不支持的包版本；支持 1.0、1.1、2.0")
    has_conv = any(n.startswith("conversation/") for n in archive.namelist())
    kind = value.get("type") or ("conversation" if has_conv else "character")
    if not isinstance(kind, str) or kind not in {"conversation", "character_package", "character", "skill"}:
        raise ValueError("未知导入包类型")
    if has_conv != (kind == "conversation"):
        raise ValueError("群聊包与独立角色/技能包不能混用")
    if value["version"] == "2.0" and kind != "conversation":
        raise ValueError("v2.0 仅用于群聊包")
    value["type"] = kind
    if kind == "conversation":
        value["startup"] = validate_startup(value.get("startup"))
    return value


def validate_startup(value: dict | None) -> dict:
    if value is None or value == {}:
        return {}
    if not isinstance(value, dict) or set(value) - {"workdir", "entrypoint", "container_port", "healthcheck_path"}:
        raise ValueError("启动配置包含不支持的字段")
    result = {"workdir": value.get("workdir", "/app"),
              "entrypoint": value.get("entrypoint", "/app/start.sh"),
              "container_port": value.get("container_port", 8000),
              "healthcheck_path": value.get("healthcheck_path")}
    for key in ("workdir", "entrypoint"):
        path = result[key]
        if not isinstance(path, str) or not (path == "/app" or path.startswith("/app/")):
            raise ValueError("启动目录和入口必须位于 /app")
        safe_path(path[1:])
    if type(result["container_port"]) is not int or not 1 <= result["container_port"] <= 65535:
        raise ValueError("容器端口必须在 1–65535")
    health = result["healthcheck_path"]
    if health is not None and (not isinstance(health, str) or not health.startswith("/") or health.startswith("//") or any(c in health for c in "\r\n\\")):
        raise ValueError("健康检查必须是本应用相对 URL 路径")
    return result


def portable_source(path: str) -> bool:
    parts = PurePosixPath(path).parts
    denied = {".git", ".venv", "venv", "node_modules", "__pycache__", ".cache", "logs", "local-secrets", ".ssh", ".aws"}
    if any(p in denied or p.startswith("._") for p in parts):
        return False
    name = parts[-1].lower()
    return not (name == ".env" or (name.startswith(".env.") and name not in {".env.example", ".env.sample"})
                or name.startswith("selfdata") or name.endswith((".pem", ".key", ".p12", ".pfx", ".log", ".pyc"))
                or name in {"id_rsa", "id_ed25519", ".ds_store", "deploy.json"})


def strip_credentials(value):
    """Model/provider credentials are never portable; text instructions remain content."""
    if isinstance(value, dict):
        return {k: strip_credentials(v) for k, v in value.items()
                if not any(word in k.lower() for word in ("password", "secret", "token", "api_key", "apikey", "private_key"))
                and k not in {"module", "module_config", "package_id", "package_role_id"}}
    if isinstance(value, list):
        return [strip_credentials(v) for v in value]
    return value
