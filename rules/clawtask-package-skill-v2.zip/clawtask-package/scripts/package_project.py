#!/usr/bin/env python3
"""Build source-only conversation v2 packages without a ClawTask installation."""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import zipfile

from package_contract import (MAX_ENTRIES, MAX_EXPANDED, MAX_FILE, MAX_UPLOAD,
                              open_package, package_manifest, portable_source,
                              safe_path, validate_startup)

PREFIX = "conversation/workspace/"
DENIED_PARTS = {".secrets", "secrets", "__MACOSX"}
DENIED_NAMES = {".git-credentials", ".npmrc", ".pypirc"}
ARCHIVES = (".zip", ".tar", ".tgz", ".gz", ".7z", ".rar", ".bz2", ".xz")
PRIVATE_KEY = re.compile(rb"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----")


def portable(name):
    parts = Path(name).parts
    return (portable_source(name) and not any(p in DENIED_PARTS for p in parts)
            and parts[-1].lower() not in DENIED_NAMES
            and not name.lower().endswith(ARCHIVES))


def inspect_content(name, data):
    if PRIVATE_KEY.search(data):
        raise ValueError(f"Suspected private key, refuse to package (do not output the text): {name}")


def validate(path):
    if path.stat().st_size > MAX_UPLOAD:
        raise ValueError("ZIP exceeds 500MiB")
    content = path.read_bytes()
    with open_package(content) as archive:
        manifest = package_manifest(archive)
        if manifest["type"] != "conversation" or manifest["version"] != "2.0":
            raise ValueError("This tool only verifies the conversation v2.0 source code package.")
        startup = manifest.get("startup")
        if not startup:
            raise ValueError("The source code package that can run must have startup.")
        meta = json.loads(archive.read("conversation/meta.json"))
        if not isinstance(meta, dict) or not isinstance(meta.get("title"), str) or not meta["title"].strip():
            raise ValueError("Conversation/meta.json must have a non-empty title")
        names = {i.filename for i in archive.infolist() if not i.is_dir()}
        entry = PREFIX + startup["entrypoint"].removeprefix("/app/")
        if entry not in names:
            raise ValueError("Startup.entrypoint is not included in the source code package")
        directory = startup["workdir"].removeprefix("/app").lstrip("/")
        if directory and not any(n.startswith(PREFIX + directory + "/") for n in names):
            raise ValueError("Startup.workdir does not exist")
        for name in names:
            if name not in {"manifest.json", "conversation/meta.json"}:
                if not name.startswith(PREFIX) or not portable(name[len(PREFIX):]):
                    raise ValueError(f"The source code contains unsupported or undistributable files: {name}")
            inspect_content(name, archive.read(name))
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        return {"output": str(path.resolve()), "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
                "startup": startup, "files": sorted(names)}


def build(source, config_path, output):
    source, output = source.resolve(), output.absolute()
    if not source.is_dir():
        raise ValueError("The source must be the project directory.")
    if output.exists() or output.is_symlink():
        raise ValueError("The output already exists; use a new file name to avoid overwriting the existing delivery package.")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or set(config) - {"title", "goal", "startup", "include", "exclude"}:
        raise ValueError("Configuration only supports title/goal/startup/include/exclude")
    for key in ("title", "goal"):
        if not isinstance(config.get(key), str) or not config[key].strip():
            raise ValueError(f"{key} must be a non-empty text")
    startup = validate_startup(config.get("startup"))
    if not startup:
        raise ValueError("Must configure startup")
    include, exclude = config.get("include"), config.get("exclude", [])
    if not isinstance(include, list) or not include or not all(isinstance(s, str) for s in include):
        raise ValueError("Include must be a non-empty file/directory path list")
    if not isinstance(exclude, list) or not all(isinstance(s, str) for s in exclude):
        raise ValueError("Exclude must be a glob text list")
    selected, skipped = {}, set()

    def visit(path):
        rel = path.relative_to(source).as_posix()
        safe_path(rel)
        if not portable(rel) or any(fnmatch.fnmatchcase(rel, p) for p in exclude):
            skipped.add(rel)
            return
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError(f"Symbol links are not allowed: {rel}")
        if stat.S_ISDIR(mode):
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(mode):
            if path.stat().st_size > MAX_FILE:
                raise ValueError(f"A single file exceeds 100MiB: {rel}")
            selected[rel] = path
        else:
            raise ValueError(f"Special files are not allowed: {rel}")

    for rel in include:
        safe_path(rel)
        path = source / rel
        # Check every ancestor, not only the selected leaf.
        if any(parent.is_symlink() for parent in [path, *path.parents] if parent != source and source in parent.parents):
            raise ValueError("Include cannot pass through the symbolic link")
        if not path.exists():
            raise ValueError(f"Include path does not exist: {rel}")
        visit(path)
    if not selected:
        raise ValueError("There is no source code to package.")
    if len(selected) + 2 > MAX_ENTRIES:
        raise ValueError("The number of files exceeds 20,000")
    metadata = {
        "manifest.json": {"version": "2.0", "type": "conversation", "title": config["title"],
                          "startup": startup, "includes": {"characters": False, "messages": False, "knowledge": False}},
        "conversation/meta.json": {"title": config["title"], "goal": config["goal"]},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(prefix=".clawtask-package-", suffix=".zip", dir=output.parent)
    os.close(handle)
    temp = Path(temp_name)
    try:
        total = 0
        with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, value in metadata.items():
                data = json.dumps(value, ensure_ascii=False, indent=2).encode()
                total += len(data)
                inspect_content(name, data)
                archive.writestr(name, data)
            for rel, path in sorted(selected.items()):
                # O_NOFOLLOW rejects a leaf swapped for a symlink during packaging.
                fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
                with os.fdopen(fd, "rb") as stream:
                    mode = os.fstat(stream.fileno()).st_mode
                    if not stat.S_ISREG(mode):
                        raise ValueError("File type changes during packaging")
                    data = stream.read(MAX_FILE + 1)
                if len(data) > MAX_FILE:
                    raise ValueError("The file exceeds the limit during the packaging period")
                total += len(data)
                if total > MAX_EXPANDED:
                    raise ValueError("The Unfolding Volume Exceeds 1GiB")
                inspect_content(rel, data)
                info = zipfile.ZipInfo(PREFIX + rel)
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | (0o755 if mode & 0o111 else 0o644)) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data)
        report = validate(temp)
        # Hard-link publishes a validated archive atomically without overwriting.
        os.link(temp, output)
        report.update(output=str(output.resolve()), excluded=sorted(skipped))
        return report
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("build")
    command.add_argument("--source", required=True, type=Path)
    command.add_argument("--config", required=True, type=Path)
    command.add_argument("--output", required=True, type=Path)
    commands.add_parser("validate").add_argument("archive", type=Path)
    args = parser.parse_args()
    try:
        report = build(args.source, args.config, args.output) if args.command == "build" else validate(args.archive)
    except (ValueError, OSError, KeyError, zipfile.BadZipFile) as exc:
        parser.exit(1, f"Packaging/verification failure: {exc}\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
